export function cn(...classes: Array<string | undefined | false>) {
  return classes.filter(Boolean).join(' ')
}

export type JLPT = 'N1' | 'N2' | 'N3' | 'N4' | 'N5' | 'None'
export type Visa = '特定技能' | '留学' | '技人国' | '永住' | '配偶者' | 'その他'

export function scoreMatch(opts: {
  candidateJLPT: JLPT
  jobMinJLPT: JLPT
  requiresSSW?: boolean
  candidateVisa: Visa
}) {
  const jlptScale = { 'N1':5,'N2':4,'N3':3,'N4':2,'N5':1,'None':0 } as const
  let score = 0
  if (jlptScale[opts.candidateJLPT] >= jlptScale[opts.jobMinJLPT]) score += 60
  if (opts.requiresSSW) {
    if (opts.candidateVisa === '特定技能') score += 40
  } else {
    score += 20
  }
  return Math.min(100, score)
}
