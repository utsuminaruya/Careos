import type { JLPT, Visa } from './utils'

export type Job = {
  id: string
  facility: string
  location: string
  employment: '正社員' | '契約' | 'パート'
  requiresSSW: boolean
  housing: boolean
  visaSupport: boolean
  jlpt: JLPT
  notes?: string
}

export type Candidate = {
  id: string
  name: string
  nationality: string
  jlpt: JLPT
  visa: Visa
  locationPref: string
  experienceYears: number
  phone?: string
  line?: string
}

export const jobs: Job[] = [
  { id: 'JPN-TYO-001', facility: 'グレイシャス春日', location: '福岡・春日市', employment: '正社員', requiresSSW: true, housing: true, visaSupport: true, jlpt: 'N3', notes: '夜勤あり・寮補助2万円' },
  { id: 'JPN-KNG-002', facility: '栄光園', location: '宮崎市', employment: '契約', requiresSSW: true, housing: false, visaSupport: true, jlpt: 'N3' },
  { id: 'JPN-TKO-003', facility: '特養・北区', location: '東京・北区', employment: '正社員', requiresSSW: true, housing: true, visaSupport: true, jlpt: 'N2', notes: '住宅手当3万円・引越し支援あり' },
]

export const candidates: Candidate[] = [
  { id: 'C-0001', name: 'Nguyen Thi A', nationality: 'ベトナム', jlpt: 'N3', visa: '特定技能', locationPref: '東京/神奈川', experienceYears: 2, line: 'https://lin.ee/xUocVyI' },
  { id: 'C-0002', name: 'Maria P', nationality: 'フィリピン', jlpt: 'N2', visa: '留学', locationPref: '埼玉/千葉', experienceYears: 1 },
  { id: 'C-0003', name: 'Siti B', nationality: 'インドネシア', jlpt: 'N4', visa: '特定技能', locationPref: '神奈川', experienceYears: 3 },
]
