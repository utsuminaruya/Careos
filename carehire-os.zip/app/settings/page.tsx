'use client'

import { useEffect, useState } from 'react'

type Settings = {
  employerLine: string
  candidateLine: string
  messenger: string
}

const DEFAULTS: Settings = {
  employerLine: 'https://lin.ee/R3ytJln',
  candidateLine: 'https://lin.ee/xUocVyI',
  messenger: 'https://www.facebook.com/MediflowKK'
}

export default function Page() {
  const [s, setS] = useState<Settings>(DEFAULTS)
  useEffect(()=>{
    const saved = typeof window !== 'undefined' ? localStorage.getItem('settings') : null
    if (saved) setS(JSON.parse(saved) as Settings)
  }, [])
  useEffect(()=>{
    if (typeof window !== 'undefined') localStorage.setItem('settings', JSON.stringify(s))
  }, [s])

  return (
    <div className="container space-y-4">
      <h1 className="text-2xl font-bold">設定</h1>
      <form className="card p-4 space-y-3" aria-label="リンク設定フォーム" onSubmit={e=>e.preventDefault()}>
        <label className="text-sm">
          <span className="block text-slate-600 mb-1">介護事業者LINE</span>
          <input className="input" value={s.employerLine} onChange={e=>setS({...s, employerLine: e.target.value})}/>
        </label>
        <label className="text-sm">
          <span className="block text-slate-600 mb-1">求職者LINE</span>
          <input className="input" value={s.candidateLine} onChange={e=>setS({...s, candidateLine: e.target.value})}/>
        </label>
        <label className="text-sm">
          <span className="block text-slate-600 mb-1">Messenger</span>
          <input className="input" value={s.messenger} onChange={e=>setS({...s, messenger: e.target.value})}/>
        </label>
        <p className="text-xs text-slate-500">これらのリンクはトップバーやCTAに反映されます（ローカル保存）。</p>
      </form>
    </div>
  )
}
