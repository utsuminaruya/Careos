'use client'

import { Stats } from '@/components/Stats'
import { jobs, candidates } from '@/lib/mock'
import Link from 'next/link'
import { useMemo } from 'react'

export default function Page() {
  const statItems = useMemo(()=>[
    { label: '求人件数', value: String(jobs.length) },
    { label: '候補者数', value: String(candidates.length) },
    { label: '想定マッチ率中央値', value: '78%' },
    { label: '今月の面談', value: '12' },
  ], [])

  return (
    <div className="container space-y-6">
      <h1 className="text-2xl font-bold">ダッシュボード</h1>
      <Stats items={statItems}/>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="card p-4">
          <h2 className="font-semibold">次の一手</h2>
          <ol className="mt-2 list-decimal ml-5 text-sm space-y-1">
            <li>東京/神奈川の特定技能求人に候補者を3名推薦</li>
            <li>LINE登録→面談予約の率を+15%改善（フォーム短縮）</li>
            <li>受入手順PDFを求人ページへ設置</li>
          </ol>
          <div className="mt-3 flex gap-2">
            <Link href="/matches" className="btn btn-primary">マッチングを見る</Link>
            <Link href="/onboarding" className="btn btn-secondary">候補者を追加</Link>
          </div>
        </div>
        <div className="card p-4">
          <h2 className="font-semibold">CTA</h2>
          <p className="text-sm text-slate-600">求人ページやSNS投稿の最後に以下を並べて設置：</p>
          <ul className="mt-2 text-sm space-y-1">
            <li>📲 <a className="link" href="https://lin.ee/xUocVyI" target="_blank">最新求人はこちら（LINE）</a></li>
            <li>💬 <a className="link" href="https://www.facebook.com/MediflowKK" target="_blank">相談はこちら（Messenger）</a></li>
          </ul>
        </div>
      </div>
    </div>
  )
}
