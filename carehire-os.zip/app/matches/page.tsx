'use client'

import { jobs, candidates } from '@/lib/mock'
import { scoreMatch } from '@/lib/utils'
import { DataTable } from '@/components/DataTable'
import Link from 'next/link'

type Row = {
  job: string
  candidate: string
  score: number
}

const rows: Row[] = []
for (const j of jobs) {
  for (const c of candidates) {
    const score = scoreMatch({ candidateJLPT: c.jlpt, jobMinJLPT: j.jlpt, requiresSSW: j.requiresSSW, candidateVisa: c.visa })
    if (score >= 60) {
      rows.push({ job: `${j.facility}（${j.location}）`, candidate: `${c.name}（${c.jlpt}/${c.visa}）`, score })
    }
  }
}
rows.sort((a,b)=>b.score-a.score)

export default function Page() {
  return (
    <div className="container space-y-4">
      <h1 className="text-2xl font-bold">マッチング</h1>
      <p className="text-sm text-slate-600">JLPT・在留資格ルールによる簡易スコア（60点以上のみ表示）。</p>
      <DataTable data={rows} columns={[
        { key: 'job', header: '求人' },
        { key: 'candidate', header: '候補者' },
        { key: 'score', header: '適合度', render: (r)=> <span className="badge">{r.score}</span> },
      ]}/>
      <div className="flex gap-2">
        <Link className="btn btn-primary" href="/onboarding">候補者を追加</Link>
        <Link className="btn btn-secondary" href="/jobs">求人を見る</Link>
      </div>
    </div>
  )
}
