'use client'

import { jobs } from '@/lib/mock'
import { JobCard } from '@/components/JobCard'
import { useMemo, useState } from 'react'
import { SearchBar } from '@/components/SearchBar'

export default function Page() {
  const [q, setQ] = useState('')
  const filtered = useMemo(()=>{
    const term = q.trim().toLowerCase()
    if (!term) return jobs
    return jobs.filter(j => [j.facility, j.location, j.employment].some(f => String(f).toLowerCase().includes(term)))
  }, [q])

  return (
    <div className="container space-y-4">
      <h1 className="text-2xl font-bold">求人</h1>
      <SearchBar onChange={setQ} placeholder="施設名・地域・雇用形態で検索"/>
      <div className="grid gap-4 md:grid-cols-2">
        {filtered.map(j => <JobCard key={j.id} job={j}/>)}
      </div>
    </div>
  )
}
