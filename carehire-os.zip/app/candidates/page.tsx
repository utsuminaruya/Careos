'use client'

import { candidates as seed } from '@/lib/mock'
import { CandidateCard } from '@/components/CandidateCard'
import { useEffect, useMemo, useState } from 'react'
import { SearchBar } from '@/components/SearchBar'

type Candidate = typeof seed[number]

function useCandidates() {
  const [data, setData] = useState<Candidate[]>([])
  useEffect(()=>{
    const local = typeof window !== 'undefined' ? window.localStorage.getItem('candidates') : null
    setData(local ? JSON.parse(local) as Candidate[] : seed)
  }, [])
  useEffect(()=>{
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('candidates', JSON.stringify(data))
    }
  }, [data])
  return { data, setData }
}

export default function Page() {
  const { data } = useCandidates()
  const [q, setQ] = useState('')
  const filtered = useMemo(()=>{
    const term = q.trim().toLowerCase()
    if (!term) return data
    return data.filter(c => [c.name, c.nationality, c.jlpt, c.locationPref, c.visa].some(f => String(f).toLowerCase().includes(term)))
  }, [q, data])

  return (
    <div className="container space-y-4">
      <h1 className="text-2xl font-bold">候補者</h1>
      <SearchBar onChange={setQ} placeholder="名前・国籍・JLPT・希望地域で検索"/>
      <div className="grid gap-4 md:grid-cols-2">
        {filtered.map(c => <CandidateCard key={c.id} c={c}/>)}
      </div>
    </div>
  )
}
