import './globals.css'
import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { SideNav } from '@/components/SideNav'
import { TopBar } from '@/components/TopBar'

export const metadata: Metadata = {
  title: 'CareHire OS',
  description: '介護人材の獲得・育成・マッチングを一気通貫で',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ja">
      <body>
        <div className="min-h-screen">
          <TopBar/>
          <div className="flex">
            <SideNav/>
            <main className="flex-1 p-4 md:p-6">{children}</main>
          </div>
        </div>
      </body>
    </html>
  )
}
