'use client'

import { useEffect, useState } from 'react'
import type { JLPT, Visa } from '@/lib/utils'
import type { Candidate } from '@/lib/mock'

export default function Page() {
  const [list, setList] = useState<Candidate[]>([])
  const [form, setForm] = useState({
    name: '', nationality: 'ベトナム', jlpt: 'N3' as JLPT, visa: '特定技能' as Visa,
    locationPref: '東京/神奈川', experienceYears: 0, line: 'https://lin.ee/xUocVyI'
  })

  useEffect(()=>{
    const local = typeof window !== 'undefined' ? window.localStorage.getItem('candidates') : null
    setList(local ? JSON.parse(local) as Candidate[] : [])
  }, [])

  function addCandidate(e: React.FormEvent) {
    e.preventDefault()
    const id = `C-${String(Math.floor(Math.random()*100000)).padStart(4,'0')}`
    const c: Candidate = { id, ...form }
    const next = [c, ...list]
    setList(next)
    if (typeof window !== 'undefined') localStorage.setItem('candidates', JSON.stringify(next))
    alert('候補者を追加しました')
  }

  return (
    <div className="container space-y-4">
      <h1 className="text-2xl font-bold">オンボーディング</h1>
      <form onSubmit={addCandidate} className="card p-4 space-y-3" aria-label="候補者追加フォーム">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="text-sm">
            <span className="block text-slate-600 mb-1">氏名</span>
            <input className="input" required value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
          </label>
          <label className="text-sm">
            <span className="block text-slate-600 mb-1">国籍</span>
            <select className="input" value={form.nationality} onChange={e=>setForm({...form, nationality:e.target.value})}>
              <option>ベトナム</option><option>フィリピン</option><option>インドネシア</option><option>ミャンマー</option><option>ネパール</option>
            </select>
          </label>
          <label className="text-sm">
            <span className="block text-slate-600 mb-1">JLPT</span>
            <select className="input" value={form.jlpt} onChange={e=>setForm({...form, jlpt:e.target.value as JLPT})}>
              <option>N1</option><option>N2</option><option>N3</option><option>N4</option><option>N5</option><option>None</option>
            </select>
          </label>
          <label className="text-sm">
            <span className="block text-slate-600 mb-1">在留資格</span>
            <select className="input" value={form.visa} onChange={e=>setForm({...form, visa:e.target.value as Visa})}>
              <option>特定技能</option><option>留学</option><option>技人国</option><option>永住</option><option>配偶者</option><option>その他</option>
            </select>
          </label>
          <label className="text-sm sm:col-span-2">
            <span className="block text-slate-600 mb-1">希望エリア</span>
            <input className="input" value={form.locationPref} onChange={e=>setForm({...form, locationPref:e.target.value})} />
          </label>
          <label className="text-sm">
            <span className="block text-slate-600 mb-1">介護経験（年）</span>
            <input className="input" type="number" min={0} value={form.experienceYears} onChange={e=>setForm({...form, experienceYears:Number(e.target.value)})} />
          </label>
          <label className="text-sm">
            <span className="block text-slate-600 mb-1">LINEリンク</span>
            <input className="input" value={form.line ?? ''} onChange={e=>setForm({...form, line:e.target.value})} />
          </label>
        </div>
        <div className="flex gap-2">
          <button className="btn btn-primary" type="submit">追加</button>
          <a className="btn btn-secondary" href="https://lin.ee/xUocVyI" target="_blank" rel="noreferrer">求職者LINEを開く</a>
        </div>
      </form>
      <div className="card p-4">
        <h2 className="font-semibold">最近追加（ローカル保存）</h2>
        {list.length === 0 ? <p className="text-sm text-slate-600 mt-1">まだありません。</p> : (
          <ul className="mt-2 list-disc ml-5 text-sm">
            {list.slice(0,5).map(c => <li key={c.id}>{c.name} / {c.nationality} / JLPT {c.jlpt}</li>)}
          </ul>
        )}
      </div>
    </div>
  )
}
