# CareHire OS (Frontend MVP)

介護人材の獲得・育成・マッチングを一気通貫で進めるための Next.js + Tailwind の最小実装。

## できること
- ダッシュボード指標表示
- 求人一覧（検索）
- 候補者一覧（検索）
- 簡易マッチング（JLPT/在留資格ベース）
- 候補者オンボーディング（ローカル保存）
- CTAリンクの設定（ローカル保存）

## 使い方
```bash
pnpm i   # or npm i / yarn
pnpm dev # http://localhost:3000
```

## デプロイ
Vercel でリポジトリを import して `Build & Output Settings` はデフォルトのまま。

## 注意
- データソースはモック＋LocalStorageです。実データ接続は API/DB 実装で置き換えてください。
- UI は Tailwind 素のコンポーネント（アクセシビリティ考慮）。
- シンプルな型安全（TypeScript）とページ分割（App Router）。
