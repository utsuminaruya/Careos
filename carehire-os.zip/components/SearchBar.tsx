'use client'

import { useState } from 'react'

export function SearchBar({ onChange, placeholder='検索' }:{ onChange:(q:string)=>void; placeholder?:string }) {
  const [q, setQ] = useState('')
  return (
    <div className="flex gap-2">
      <input
        className="input"
        placeholder={placeholder}
        value={q}
        onChange={(e)=>{ setQ(e.target.value); onChange(e.target.value) }}
        aria-label={placeholder}
      />
    </div>
  )
}
