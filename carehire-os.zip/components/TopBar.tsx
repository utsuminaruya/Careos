'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useState } from 'react'

export function TopBar() {
  const [open, setOpen] = useState(false)
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-white">
      <div className="container flex h-14 items-center gap-4">
        <Link href="/" className="flex items-center gap-2" aria-label="ホームへ">
          <Image src="/logo.svg" width={120} height={28} alt="CareHire OS ロゴ"/>
        </Link>
        <div className="ml-auto flex items-center gap-2">
          <Link className="btn btn-secondary" href="https://lin.ee/R3ytJln" target="_blank" rel="noreferrer">介護事業者LINE</Link>
          <Link className="btn btn-primary" href="https://lin.ee/xUocVyI" target="_blank" rel="noreferrer">求職者LINE</Link>
        </div>
      </div>
    </header>
  )
}
