import type { Job } from '@/lib/mock'

export function JobCard({ job }: { job: Job }) {
  return (
    <article className="card p-4" aria-label={job.facility}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="text-lg font-semibold">{job.facility}</h3>
          <p className="text-sm text-slate-600">{job.location}・{job.employment}</p>
        </div>
        <div className="space-x-2">
          {job.requiresSSW && <span className="badge badge-green">特定技能OK</span>}
          {job.housing && <span className="badge">住宅</span>}
          {job.visaSupport && <span className="badge">VISA支援</span>}
          <span className="badge">JLPT {job.jlpt}〜</span>
        </div>
      </div>
      {job.notes && <p className="mt-2 text-sm text-slate-700">{job.notes}</p>}
    </article>
  )
}
