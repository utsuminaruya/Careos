'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'

const items = [
  { href: '/', label: 'ダッシュボード' },
  { href: '/jobs', label: '求人' },
  { href: '/candidates', label: '候補者' },
  { href: '/matches', label: 'マッチング' },
  { href: '/onboarding', label: 'オンボーディング' },
  { href: '/settings', label: '設定' },
]

export function SideNav() {
  const pathname = usePathname()
  return (
    <aside className="hidden md:block w-56 border-r bg-white">
      <nav className="p-4 space-y-1">
        {items.map(item => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              'block rounded-md px-3 py-2 text-sm hover:bg-slate-50',
              pathname === item.href ? 'bg-slate-100 font-semibold' : 'text-slate-700'
            )}
            aria-current={pathname === item.href ? 'page' : undefined}
          >
            {item.label}
          </Link>
        ))}
      </nav>
    </aside>
  )
}
