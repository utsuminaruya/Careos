type Stat = { label: string, value: string, caption?: string }
export function Stats({ items }: { items: Stat[] }) {
  return (
    <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {items.map((s, i) => (
        <div key={i} className="card p-4">
          <div className="text-sm text-slate-500">{s.label}</div>
          <div className="mt-1 text-2xl font-semibold">{s.value}</div>
          {s.caption && <div className="mt-1 text-xs text-slate-500">{s.caption}</div>}
        </div>
      ))}
    </section>
  )
}
