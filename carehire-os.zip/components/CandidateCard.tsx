import type { Candidate } from '@/lib/mock'

export function CandidateCard({ c }: { c: Candidate }) {
  return (
    <article className="card p-4" aria-label={c.name}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="text-lg font-semibold">{c.name}</h3>
          <p className="text-sm text-slate-600">{c.nationality}・JLPT {c.jlpt}・{c.experienceYears}年経験</p>
          <p className="text-xs text-slate-500">希望: {c.locationPref}・在留:{c.visa}</p>
        </div>
        {c.line && <a className="btn btn-secondary" href={c.line} target="_blank" rel="noreferrer" aria-label="LINEへ">LINE</a>}
      </div>
    </article>
  )
}
