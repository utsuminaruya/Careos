'use client'

import { useMemo } from 'react'

type Column<T> = {
  key: keyof T
  header: string
  render?: (row:T)=>React.ReactNode
}
export function DataTable<T extends object>({ data, columns }: { data: T[]; columns: Column<T>[] }) {
  const headers = useMemo(()=>columns.map(c=>c.header), [columns])
  return (
    <div className="overflow-x-auto card">
      <table className="min-w-full divide-y divide-slate-200">
        <thead className="bg-slate-50">
          <tr>
            {headers.map((h,i)=>(<th key={i} className="px-4 py-2 text-left text-xs font-medium text-slate-600">{h}</th>))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {data.map((row, i)=>(
            <tr key={i} className="hover:bg-slate-50">
              {columns.map((c, j)=>(
                <td key={j} className="px-4 py-2 text-sm">
                  {c.render ? c.render(row) : String(row[c.key])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
